$(function($) {

    "use strict";

        // For page transitions
        $(".animsition").animsition();

});
